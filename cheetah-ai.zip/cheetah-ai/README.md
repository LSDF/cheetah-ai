# Cheetah AI — Self-Improving Agent

Autonomous AI that can chat, remember, use tools, and improve itself.

**Config:**
- Model Provider: API (OpenRouter / Grok / Claude / OpenAI compatible)
- Modes: Private + Public
- Self-modification: Enabled (scaffolded)

---

## Deploy on Railway (No VPS needed)

### 1. Prepare
- Create a free account at [railway.app](https://railway.app)

### 2. Push to GitHub (Recommended)
```bash
cd cheetah-ai
git init
git add .
git commit -m "Cheetah AI v0.1"
# Create a new repo on GitHub and push
```

### 3. Deploy on Railway
1. Go to Railway → **New Project** → **Deploy from GitHub repo**
2. Select your Cheetah AI repo
3. Add these **Environment Variables** in Railway:

```
OPENROUTER_API_KEY = your_key_here
MODEL = anthropic/claude-3.5-sonnet
```

4. Railway will auto-detect Python and start the service.
5. Go to **Settings** → **Networking** → Generate Domain.

### 4. Done
Your Cheetah AI will be live on the Railway public URL.

---

## Local Development

```bash
cd cheetah-ai
python -m venv venv
source venv/bin/activate
pip install -r backend/requirements.txt
cp backend/.env.example backend/.env
# Add your API key inside .env

uvicorn backend.main:app --reload --port 8000
```

Open → http://localhost:8000

---

## Project Structure

```
cheetah-ai/
├── backend/
│   ├── main.py
│   ├── agent/
│   │   ├── core.py
│   │   ├── tools.py
│   │   └── memory.py
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   └── index.html
├── data/
├── Procfile
├── railway.toml
└── README.md
```
